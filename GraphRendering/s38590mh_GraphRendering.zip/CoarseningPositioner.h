#pragma once
#include "GraphEL.h"

#include <vector>
#include <set>

class CoarseningPositioner
{
private:
public:
	std::vector<std::set<int>> createFiltration(const GraphEL& graph);

	std::vector<std::vector<std::vector<std::pair<int, int>>>> findNeighbourhoods(const GraphEL& graph, const std::vector<std::set<int>>& filtration);

	std::vector<std::vector<std::vector<std::pair<int, int>>>> fastFindNeighbourhoods(const GraphEL& graph, const std::vector<std::set<int>>& filtration);

	std::vector<int> findParentNodes(const GraphEL& graph, const std::vector<std::set<int>>& filtration);

public:
	int iters;
	int neighbourhoodSize;
	float randRange;
	float springStrength;
	float edgeLength;
	sf::Vector2f centerCoords;

	void positionVerticesGPU(GraphEL& graph);
	
	void positionVertices(GraphEL& graph);
	
	std::string getConfigStr();
};